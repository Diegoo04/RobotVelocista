# RobotVelocista
Robot velocista /// Race robot ///
-Primer día:
  Hoy hemos hecho el esquema de la placa de los sensores y hemos empezado a hacer la PCB.🏎🔥
-Segundo día:
  Hoy he enrutado las redes y ahora estoy nombrando los pines en la placa.✏
